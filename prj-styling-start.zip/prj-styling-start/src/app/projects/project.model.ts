export interface Project {
  name: string;
  description: string;
  status: string;
}
